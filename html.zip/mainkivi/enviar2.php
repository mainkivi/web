<?php
if (isset($_POST['name']))
    $name = $_POST['name'];
if (isset($_POST['email']))
    $email = $_POST['email'];
if (isset($_POST['message']))
    $message = $_POST['message'];
if (isset($_POST['subject']))
    $subject = $_POST['subject'];
?>
<?php
include_once "head.php";
?>
<div style="height: 100vh">
    <div class="flex-center flex-column font-weight-bold">
        <div class="row">
            <div class="col-12">
                <div class="text-center text-md-center">
                    <?php
                    if ($name == "" && $email == "" && $message == "" && $subject == "") {
                        echo 'Has de plenar tots els camps!!<br>Tornem a la pàgina inicial en 10 segons.<br>';
                        header("refresh:10;url=..");
                    } elseif ($name == "") {
                        echo 'No has ficat el nom<br> Has de plenar tots els camps!!<br>Tornem a la pàgina inicial en 10 segons.<br>';
                        header("refresh:10;url=index.php");
                    } elseif ($email == "") {
                        echo 'No has ficat un email<br>Has de plenar tots els camps!!<br>Tornem a la pàgina inical en 10 segons.<br>';
                        header("refresh:10;url=index.php");
                    } elseif ($subject == "") {
                        echo 'No has ficat un Assumpte<br>Has de plenar tots els camps!!<br>Tornem a la pàgina inicial en 10 segons.<br>';
                        header("refresh:10;url=index.php");
                    } else {
                        /*
                        $content = "From: $name \n Email: $email \n Message: $message";
                        $recipient = "info@mainkivi.info";
                        $mailheader = "De: $email \r\n";
                        echo '<div class="alert-primary">';
                        mail($recipient, utf8_decode($subject), utf8_decode($content), $mailheader) or die("<br>Error!");
                        */
                        echo "<div class=alert-primary p-5>";
                        echo "El teu missatge <br><br>  " . $content . "<br>s'ha enviat correctament<br><br>";
                        echo "<br>Email enviat!<br><br>La pàgina es torna a l'índex.";
                        echo "</div>";
                        header("refresh:10;url=index.php");
                    }
                    ?>

                    <a href="index.php" class="btn btn-primary"">O clica aquí</a>
                </div>

            </div>
        </div>
    </div>
</div>




<?php
include_once 'foot.php';
?>