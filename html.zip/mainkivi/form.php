<form id="contact-form" name="contact-form" action="enviar2.php" method="POST">

    <!--Grid row-->
    <div class="row">

        <!--Grid column-->
        <div class="col-md-6">
            <div class="md-form mb-0">
                <input type="text" id="name" name="name" class="form-control">
                <label for="name" class="">El teu nom:</label>
            </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-6">
            <div class="md-form mb-0">
                <input type="text" id="email" name="email" class="form-control">
                <label for="email" class="">El teu email</label>
            </div>
        </div>
        <!--Grid column-->

    </div>
    <!--Grid row-->

    <!--Grid row-->
    <div class="row">
        <div class="col-md-12">
            <div class=" md-form mb-0">
                <input type="text" id="subject" name="subject" class="form-control">
                <label for="subject" class="">Assumpte:</label>
            </div>
        </div>
    </div>
    <!--Grid row-->

    <!--Grid row-->
    <div class="row">

        <!--Grid column-->
        <div class="col-md-12">

            <div class=" md-form">
                <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                <label for="message">El teu missatge: (fiqueu també un telèfon de contacte)</label>
            </div>

        </div>
    </div>
    <!--Grid row-->
    <div class="text-center text-md-right">
        <!--<a class="btn btn-primary" onclick="document.getElementById('contact-form').submit();">Envia</a>-->
        <a class="btn btn-primary" onclick="document.getElementById('contact-form').submit();">Envia</a>
    </div>


</form>