<?php
include_once "head.php";
?>

<!--Navbar -->

<nav class="navbar fixed-top navbar-expand-lg navbar-dark scrolling-navbar">
  <div class="container">
    <a class="navbar-brand" href="#">MaInKiVi</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333" aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#inici">Inici
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#quisoc">Qui soc jo?
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#documentacio">Documentació
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contacta">Contacta
            <span class="sr-only">(current)</span>
          </a>
        </li>
      </ul>

      <!-- Social icons-->

      <ul class="navbar-nav ml-auto nav-flex-icons">
        <li class="nav-item">
          <a class="nav-link waves-effect waves-light" href="wiki1/index.php/P%C3%A0gina_principal" target="_blank"><i class="fab fa-wikipedia-w"></i></a>
        </li>

        <li class="nav-item">
          <a href="https://twitter.com/mainkivi" class="nav-link waves-effect waves-light">
            <i class="fab fa-twitter"></i>
          </a>
        </li>
        <li class="nav-item">
          <a href="http://www.facebook.com/enrique.vilchez" class="nav-link waves-effect waves-light">
            <i class="fab fa-facebook-f"></i>
          </a>
        </li>
        <li class="nav-item">
          <a href="https://www.instagram.com/kik_evil_chez/" class="nav-link waves-effect waves-light">
            <i class="fab fa-instagram"></i>
          </a>
        </li>
        <li class="nav-item">
          <a href="https://www.linkedin.com/in/enrique-jos%C3%A9-vilchez-p%C3%A9rez-56327926/" class="nav-link waves-effect waves-light">
            <i class="fab fa-linkedin"></i>
          </a>
        </li>
        <li class="nav-item">
          <a href="https://www.youtube.com/watch?v=aQpb--wEQ6w&list=PL8BaVn7vSwVHbYXQCbkMndsAneF17J52W" class="nav-link waves-effect waves-light">
            <i class="fab fa-youtube"></i>
          </a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-tools"></i>
            Espai personal
          </a>
          <div class="dropdown-menu dropdown-menu-right dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
            <a class="dropdown-item" href="facturascripts" target="_blank"><i class="fas fa-file-invoice-dollar"></i>
              Facturació</a>
            <a class="dropdown-item" href="roundcube/" target="_blank"><i class="fas fa-envelope-open-text"></i>
              Lectura de correu</a>
            <a class="dropdown-item" href="nextcloud/" target="_blank"><i class="fas fa-hdd"></i> NextCloud</a>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!--/.Navbar -->

<!-- Start your project here-->
<!-- Background image and description-->

<div class=" view">
  <section id="inici">
    <div class="full-bg-img">

      <div class="mask rgba-black-strong flex-center">
        <div class="container text-center white-text wow fadeInUp">

          <h1>MAINKIVI</h1>
          <h5>Manteniment informàtic per Kike Vilchez</h5>

          <br>
          <p>Benvinguts a la meva pàgina web on intento concentrar els meus coneixements sobre el mon informàtic,
            normalment dedicat a l'ús de programari obert i lliure aplicat als nostres dies.</p>

          <p>Dins d'aquesta pàgina podreu accedir al manual en format <b>Wiki</b> amb informació relacionada al
            treball
            amb servidors <b>Linux Ubuntu</b> i estacions de treball tant <b>Linux</b> com <b>Windows</b>. En el cas
            del
            treball en Linux el dedicaré, sobretot, en la distribució <a href="http://linkat.xtec.cat">Linkat </a>que
            s'utilitza en les <b>Escoles i Instituts de Catalunya</b> i que te la base en <b>Ubuntu</b>. Igualment
            tinc
            costum de deixar petits video-tutorials en el meu canal de <b>Youtube</b>.</p>
        </div>
      </div>
    </div>
</div>
</section>

<!--Main Layout-->
<main class="text-center py-5">

  <section id="quisoc">
    <div style="height: 100vh">
      <div class="flex-center flex-column container wow fadeInUp">
        <div class="row">
          <div class="col-lg-4 col-md-12 mb-4">

            <!--Card-->
            <div class="card testimonial-card">

              <!--Background color-->
              <div class="card-up teal lighten-5">
              </div>

              <!--Avatar-->
              <div class="avatar mx-auto white"><img src="img/me.jpg" width="120" alt="avatar mx-auto white" class="rounded-circle img-fluid">
              </div>

              <div class="card-body">
                <!--Name-->
                <h4 class="card-title mt-1">Enrique José Vílchez Pérez</h4>
                <hr>
                <!--Quotation-->
                <p><i class="fas fa-quote-left"></i> Tècnic informàtic i dessenvolupador de programari lliure</p>
              </div>

            </div>
            <!--Card-->

          </div>
          <div class="col-md-8 m-md-auto">
            <p>Soc <strong>tècnic informàtic</strong> que s'ha volgut dedicar al treball amb el programari lliure tant
              a
              la llar com a un entorn educatiu com professional</p>
            <p>Es pèr això que, dins aquest web intentaré, de la manera més senzilla possible, donar informació sobre
              <b>Sistemes Operatius i programari lliure</b> i, si s'escau, privatiu però gratuït. </p>
            <p>Durant el pas dels anys m'he intentat especialitzar en el desenvolupament i treball de distribucions
              Linux dins de l'àmbit de treball domèstic i escolar, i comparteixo els meus coneixements per tal que
              altres usuaris també tinguin la possibilitat de llençar-se al canvi. és per això que acumulo i resumeixo
              el contingut en ela web en format <a href="https://mainkivi.info/index.php" target="_blank">Wiki</a> i
              en
              una serie de video-tutorials en el meu canal de <a href="https://www.youtube.com/watch?v=aQpb--wEQ6w&amp;list=PL8BaVn7vSwVHbYXQCbkMndsAneF17J52W" target="_blank">Youtube</a></p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="documentacio" class="mask rgba-lime-light">
    <div class="view2">
      <div class="full-bg-img">
        <div class="container p-lg-5 pt-lg-5">
          <div class="flex-center flex-column wow fadeInUp">
            <div class="row ">
              <div class="col-lg-12 col-md-12 m-md-auto">
                <h1>Documentació</h1>
                <p>
                  Des d'aquí podràs accedir les seccions dedicades a documentar i informar els meus coneixements.
                </p>
                <p>
                  Podràs accedir a la meva <b>Wiki</b> on vaig actualitzant dia a dia tota la informació que vaig
                  recollint.
                </p>
                <p>
                  Podràs accedir al meu canal a <b>Youtube</b> on tinc video-tutorials tant meus com altres que
                  trobo
                  interessant.
                </p>
                <p>
                  Per últim, podràs accedir a una secció de descàrregues amb <b>imatges personalitzades i
                    scripts</b>
                  entre altres.
                </p>
              </div>
            </div>
            <div class="item row">
              <div class=" col-lg-4 col-md-12 m-md-auto">
                <div class="item well card-body">
                  <a href="wiki1/index.php/P%C3%A0gina_principal" target="_blank">
                    <img src="img/logoWiki.png" class="size-full wp-image-8062" style="width:130px" alt="Wiki">
                    <p class="btn btn-primary">Accedeix a la Wiki</p>
                  </a>

                </div>
              </div>
              <div class="col-lg-4 col-md-6 m-md-auto">
                <div class="item well card-body">
                  <a href="https://www.youtube.com/watch?v=aQpb--wEQ6w&list=PL8BaVn7vSwVHbYXQCbkMndsAneF17J52W" target="_blank">
                    <img src=" img/logoYoutube.png" class=" size-full wp-image-8062" style="width:130px" alt="Canal de Youtube">
                    <p class="btn btn-primary">Accés a Youtube</p>
                  </a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 m-md-auto">
                <div class="item well card-body">
                  <a href="ftp://mainkivi.info/" target="_blank">
                    <img src="img/baixa.png" class="size-full wp-image-8062" style="width:130px" alt="Baixades">
                    <p class="btn btn-primary">Accés descàrregues</p>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

  </section>


  <section id="contacta" class=" rgba-grey-light">
    <div style="height: 100vh">
      <div class="flex-center flex-column container wow fadeInUp">

        <!--Section: Contact v.2-->
        <section class="mb-4">
          <!--Section heading-->
          <h2 class="h1-responsive font-weight-bold text-center my-4">Contacta amb mi</h2>
          <!--Section description-->
          <p class="text-center w-responsive mx-auto mb-5">
            Tens cap pregunta? Vols contactar amb mi?
            Pots plenar aquest formulari i tant prompte pugui et respondré. Deixa el teu missatge i un telf. de
            contacte.
            Gracies!!
          </p>
          <div class="mt-0 m-md-2">
            <a href="https://twitter.com/mainkivi" class="nav-link waves-effect waves-light">
              <i class="fab fa-twitter"></i>
            </a>


            <a href="http://www.facebook.com/enrique.vilchez" class="nav-link waves-effect waves-light">
              <i class="fab fa-facebook-f"></i>
            </a>


            <a href="https://www.instagram.com/kik_evil_chez/" class="nav-link waves-effect waves-light">
              <i class="fab fa-instagram"></i>
            </a>


            <a href="https://www.linkedin.com/in/enrique-jos%C3%A9-vilchez-p%C3%A9rez-56327926/" class="nav-link waves-effect waves-light">
              <i class="fab fa-linkedin"></i>
            </a>
          </div>

          <div class="row">
            <!--Grid column-->
            <div class="col-md-2"></div>
            <div class="col-md-8 mb-md-0 mb-5">
              <?php
              include_once "form.php";
              ?>
            </div>
            <!--Grid column-->
          </div>
          <div class="col-md-2"></div>

        </section>
        <!--Section: Contact v.2-->

      </div>
    </div>

  </section>


  <!-- End your project here-->



  <?php
  include_once "foot.php";
  ?>